---
published: true
---
## Technology Change as the Great Equalizer

Here is a thought provoking article by [DIMITRI KANEVSKY](https://obamawhitehouse.archives.gov/blog/2012/05/07/technology-change-great-equalizer) that details how technology and innovation will be the fundamental achievements that allow for true equality in STEM.
