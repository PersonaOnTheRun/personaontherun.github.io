---
published: ture
---
## Naive Bayes classifier - scikit-learn

#MachineLearning #AI #Python #scikit-learn

Welcome to the first of many daily blog posts.

In this one we are going to dive into [Naive Bayes](http://scikit-learn.org/stable/modules/naive_bayes.html). This is a scikit-learn library for Python3. 


### What is it?


### How does it work?



### Use Cases



### Further Reading

[Naive Bayes Wikipedia](https://en.wikipedia.org/wiki/Naive_Bayes_classifier)

[scikit-learn.org](http://scikit-learn.org/stable/modules/naive_bayes.html)
