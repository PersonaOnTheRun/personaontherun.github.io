---
layout: page
title: About
permalink: /about/
---

Technology is the great equalizer that can dramatically improve the quality of a person’s life through the click of a mouse button. Technology is constantly evolving to remove barriers that emerge due to a person’s social characteristics, geographic location, physical or sensory abilities.

### More Information

A place to include any other types of information that you'd like to include about yourself.

### Contact me

[personaonthemailbox@gmail.com](mailto:personaonthemailbox@gmail.com)
